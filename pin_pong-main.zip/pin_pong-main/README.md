It's simple game for studen's that we are creating during lessons
